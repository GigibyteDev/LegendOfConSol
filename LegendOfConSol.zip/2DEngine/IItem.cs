﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2DEngine
{
    public interface IItem
    {
        string Name { get; set; }

    }
}